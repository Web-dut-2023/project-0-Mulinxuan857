# Git

Git is a version control tool that can be used to keep track of versions of a software project.

## GitHub

GitHub is an online service for hosting git repositories.
