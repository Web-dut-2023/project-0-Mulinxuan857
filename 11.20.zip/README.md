
## Index
* `/ `

Welcome! It has one side bar and will list all pages.

## Entry
* `/wiki/<str:title>/`

This page llustrates the pages using python-markdown2, and will return error if no pages are found.

## Search
* `/search/`

This is the searching page, using q parameter to search.

## New_page
* `/new_page/`

This page creates one new page, needs one \[title\] and one \[content\] (in markdown grammer)

## Random_page
* `/random_page`

This page returns one random page